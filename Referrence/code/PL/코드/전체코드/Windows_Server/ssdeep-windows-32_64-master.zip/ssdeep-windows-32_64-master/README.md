ssdeep Python Wrapper for Windows
=================================

Fork includes `fuzzy_64.dll` allowing the ssdeep to run on 32 and 64 bit python.

#### Install:

1. Download (and extract) / clone this repo into a folder.
2. In said folder run `python setup.py install`.

ssdeep by Jesse Kornblum (http://ssdeep.sourceforge.net).
Inspired by python-ssdeep (https://github.com/DinoTools/python-ssdeep).
