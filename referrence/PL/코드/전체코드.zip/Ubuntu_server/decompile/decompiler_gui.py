import host.ui

if __name__ == '__main__':
  host.ui.main.show_decompiler()
